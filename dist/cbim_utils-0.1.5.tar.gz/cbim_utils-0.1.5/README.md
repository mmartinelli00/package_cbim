# Documentazione Moduli

## db_connection.py: 
Get a connection to a MySQL database from a url style connection string. (Param url: MySQL connection string, e.g.: mysql://user:password@hostname:port/database)